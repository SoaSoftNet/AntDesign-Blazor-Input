﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
namespace MyAntDesignApp
{
    public class CustomerQuotePrintingViewModel : ViewModelsBase
    {
        public string QuoteId { get; set; }
        [Display(Name = "公式名称")]
        [Required(ErrorMessage = "请选择成本计算公式")]
        public string FormulaName
        {
            get;
            set;
        }
        public List<ListItemEntity> lstFormula { get; set; } = new List<ListItemEntity>();

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "加工费/㎡")]
        [Range(0.00, 10000000.00, ErrorMessage = "请输入每平方加工费")]
        public decimal ProcessingFees
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "原材宽度")]
        [Range(0.00, 10000000.00, ErrorMessage = "请输入原材宽度")]
        public decimal RawmaterialWidth
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "原材料克重")]
        [Range(0.00, 10000000.00, ErrorMessage = "请输入原材料克重")]
        public decimal RawmaterialGramWeight
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "KG/吨")]
        [Range(0.00, 10000000.00, ErrorMessage = "请输入KG/吨")]
        public decimal WeightCost
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "㎡/吨")]
        [Range(0.00, 10000000.00, ErrorMessage = "请输入㎡/吨")]
        public decimal WeightArea
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "印刷损耗%")]
        [Range(0.00, 10000000.00, ErrorMessage = "请输入印刷损耗%")]
        public decimal PrintingLoss
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "排版损耗%")]
        [Range(0.00, 10000000.00, ErrorMessage = "请输入排版损耗%")]
        public decimal ShiftLoss
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "税%")]
        [Range(0.00, 10000000.00, ErrorMessage = "请输入税率%")]
        public decimal Tax
        {
            get;
            set;
        }
        [Display(Name = "利润率")]
        public decimal ProfitMargin
        {
            get; set;
        }
        [Display(Name = "印刷成本")]
        [Range(0.00, 10000000.00, ErrorMessage = "请输入印刷成本元/吨")]
        public decimal PrintingCost { get; set; }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "AmountFormula")]
        public string AmountFormula
        {
            get;
            set;
        }
        ///<summary>
        ///
        ///</summary>
        [Display(Name = "Remark")]
        public string Remark
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "Creator")]
        public string Creator
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "ModifyBy")]
        public string ModifyBy
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "CreatedOn")]
        public DateTime CreatedOn
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "UpdatedOn")]
        public DateTime UpdatedOn
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "SortCode")]
        public int SortCode
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "Deleted")]
        public bool Deleted
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "CreatorUserId")]
        public string CreatorUserId
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "ModifyUserId")]
        public string ModifyUserId
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "DeleterUserId")]
        public string DeleterUserId
        {
            get;
            set;
        }
    }
}
