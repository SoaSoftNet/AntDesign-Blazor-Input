﻿namespace MyAntDesignApp
{
    public class ViewModelsBase
    {
        public string Id { get; set; }
    }
}
