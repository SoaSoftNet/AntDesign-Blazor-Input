﻿using System.Collections.Generic;
namespace MyAntDesignApp
{
    public class ListItemEntity
    {
        /// <summary>
        /// 编号
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// 显示的内容
        /// </summary>
        public string Title { get; set; }
        /// <summary>
        /// 父编号
        /// </summary>
        public string ParentId { get; set; }
        /// <summary>
        /// 是否选中
        /// </summary>
        public bool Selected { get; set; }
        public string Ext1Title { get; set; }
        public string Ext2Title { get; set; }
        public string Ext3Title { get; set; }

        public List<ListItemEntity> lstSubItem { get; set; }
    }
}
