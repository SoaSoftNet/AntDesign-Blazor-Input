﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace MyAntDesignApp
{
    public class CustomerQuoteCoatingViewModel : ViewModelsBase
    {
        public string QuoteId { get; set; }
        [Display(Name = "公式名称")]
        [Required(ErrorMessage = "请选择成本计算公式")]
        public string FormulaName { get; set; }
        public List<ListItemEntity> lstFormula { get; set; } = new List<ListItemEntity>();

        [Display(Name = "原纸价格")]
        [Range(0.00, 10000000.00, ErrorMessage = "请输入原纸价格（/吨）")]
        public decimal BasePaperPrice { get; set; }

        [Display(Name = "纸张克重")]
        [Range(0.00, 10000000.00, ErrorMessage = "请输入纸张克重（g）")]
        public decimal PaperWeight { get; set; }
        [Display(Name = "涂布克重")]
        [Range(0.00, 10000000.00, ErrorMessage = "请输入涂布克重（g）")]
        public decimal CoatingWeight { get; set; }
        [Display(Name = "原纸重量")]
        [Range(0.00, 10000000.00, ErrorMessage = "请输入原纸重量（kg）")]
        public decimal BasePaperWeight { get; set; }
        [Display(Name = "胶水成本")]
        [Range(0.00, 10000000.00, ErrorMessage = "请输入胶水成本（kg）")]
        public decimal GlueCost { get; set; }
        [Display(Name = "涂布成本")]
        public decimal CoatingCost { get; set; }
        [Display(Name = "利润率")]
        public decimal ProfitMargin
        {
            get; set;
        }
        [Display(Name = "涂布金额公式")]
        public string AmountFormula { get; set; }

        [StringLength(500, ErrorMessage = "备注长度为1~500")]
        [Display(Name = "备注")]
        public string Remark { get; set; }
        public string Creator { get; set; }
        public string ModifyBy { get; set; }
        [Display(Name = "创建时间")]
        public DateTime CreatedOn { get; set; }

        public DateTime UpdatedOn { get; set; }
        public bool Deleted { get; set; }
        public Int32 SortCode { get; set; }
        public string CreatorUserId { get; set; }
        public string ModifyUserId { get; set; }
        public string DeleterUserId { get; set; }
    }
}
