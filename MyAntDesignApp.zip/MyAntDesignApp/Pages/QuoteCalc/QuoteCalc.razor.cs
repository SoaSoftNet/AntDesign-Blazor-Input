﻿using AntDesign.TableModels;
using AntDesign;
using Microsoft.AspNetCore.Components;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Linq;
using System.Data;

namespace MyAntDesignApp.Pages.QuoteCalc
{
    public partial class QuoteCalc
    {
        [Inject] public MessageService messageService { get; set; }
        [Inject] public NotificationService _notice { get; set; }
        [Inject] public NavigationManager navigationManager { get; set; }
        CustomerQuoteCoatingViewModel CoatingViewModel = new CustomerQuoteCoatingViewModel();
        CustomerQuotePrintingViewModel PrintingViewModel = new CustomerQuotePrintingViewModel();
        string CoatingFormula = string.Empty;
        string PrintingFormula = string.Empty;
        protected override async Task OnInitializedAsync()
        {
            await GetCoatingFormula();
            await GetPrintingFormula();
        }
        async void OnCoatingFormulaSelectChanged(ListItemEntity listItemEntity)
        {
            if (listItemEntity != null)
            {

                if (!string.IsNullOrEmpty(listItemEntity.Ext2Title))
                {
                    foreach (var item in listItemEntity.Ext2Title.Split(';'))
                    {
                        string[] subitem = item.Split('=');
                        if (subitem[0] == "BP")
                        {
                            CoatingViewModel.BasePaperPrice = decimal.Parse(subitem[1]);
                        }
                        else if (subitem[0] == "PW")
                        {
                            CoatingViewModel.PaperWeight = decimal.Parse(subitem[1]);
                        }
                        else if (subitem[0] == "CW")
                        {
                            CoatingViewModel.CoatingWeight = decimal.Parse(subitem[1]);
                        }
                        else if (subitem[0] == "BW")
                        {
                            CoatingViewModel.BasePaperWeight = decimal.Parse(subitem[1]);
                        }
                        else if (subitem[0] == "GC")
                        {
                            CoatingViewModel.GlueCost = decimal.Parse(subitem[1]);
                        }
                        else if (subitem[0] == "PM")
                        {
                            CoatingViewModel.ProfitMargin = decimal.Parse(subitem[1]);
                        }
                    }

                }
                else
                {

                    CoatingViewModel.BasePaperPrice = 0.00m;
                    CoatingViewModel.PaperWeight = 0.00m;
                    CoatingViewModel.CoatingWeight = 0.00m;
                    CoatingViewModel.BasePaperWeight = 0.00m;
                    CoatingViewModel.GlueCost = 0.00m;
                    CoatingViewModel.ProfitMargin = 0.00m;
                    CoatingFormula = string.Empty;
                }
                CoatingFormula = listItemEntity.Ext1Title;
            }
            else
            {
                CoatingViewModel.BasePaperPrice = 0.00m;
                CoatingViewModel.PaperWeight = 0.00m;
                CoatingViewModel.CoatingWeight = 0.00m;
                CoatingViewModel.BasePaperWeight = 0.00m;
                CoatingViewModel.GlueCost = 0.00m;
                CoatingViewModel.ProfitMargin = 0.00m;
                CoatingFormula = string.Empty;
            }
            await CoatingFormulaCalc();
        }
        async Task CoatingFormulaCalc(decimal value = 0.00m)
        {
            try
            {
                string currentFormula = CoatingFormula;
                currentFormula = currentFormula.Replace("BP", CoatingViewModel.BasePaperPrice.ToString()).Replace("PW", CoatingViewModel.PaperWeight.ToString()).Replace("CW", CoatingViewModel.CoatingWeight.ToString());
                currentFormula = currentFormula.Replace("BW", CoatingViewModel.BasePaperWeight.ToString()).Replace("GC", CoatingViewModel.GlueCost.ToString()).Replace("PM", CoatingViewModel.ProfitMargin.ToString());
                DataTable dt = new DataTable();
                CoatingViewModel.CoatingCost = decimal.Parse(dt.Compute(currentFormula, "").ToString());
            }
            catch (Exception ex)
            {
                await messageService.Error("计算公式错误，请确认", 2);
            }
            await Task.CompletedTask;
        }
        async Task GetCoatingFormula()
        {
            CoatingViewModel.lstFormula.Add(new ListItemEntity() { Id = "1", Title = "公式1", Ext2Title = "PW*GC" });
            await Task.CompletedTask;
        }
        async Task GetPrintingFormula()
        {
            await Task.CompletedTask;
        }

        async Task OnPrintingFormulaSelectChanged(ListItemEntity listItemEntity)
        {
            if (listItemEntity != null)
            {
                if (!string.IsNullOrEmpty(listItemEntity.Ext2Title))
                {
                    foreach (var item in listItemEntity.Ext2Title.Split(';'))
                    {
                        string[] subitem = item.Split('=');
                        if (subitem[0] == "PE")
                        {
                            PrintingViewModel.ProcessingFees = decimal.Parse(subitem[1]);
                        }
                        else if (subitem[0] == "RW")
                        {
                            PrintingViewModel.RawmaterialWidth = decimal.Parse(subitem[1]);
                        }
                        else if (subitem[0] == "RG")
                        {
                            PrintingViewModel.RawmaterialGramWeight = decimal.Parse(subitem[1]);
                        }
                        else if (subitem[0] == "WC")
                        {
                            PrintingViewModel.WeightCost = decimal.Parse(subitem[1]);
                        }
                        else if (subitem[0] == "WA")
                        {
                            PrintingViewModel.WeightArea = decimal.Parse(subitem[1]);
                        }
                        else if (subitem[0] == "PL")
                        {
                            PrintingViewModel.PrintingLoss = decimal.Parse(subitem[1]);
                        }
                        else if (subitem[0] == "SL")
                        {
                            PrintingViewModel.ShiftLoss = decimal.Parse(subitem[1]);
                        }
                        else if (subitem[0] == "T")
                        {
                            PrintingViewModel.Tax = decimal.Parse(subitem[1]);
                        }
                    }

                }
                else
                {

                    PrintingViewModel.ProcessingFees = 0.00m;
                    PrintingViewModel.RawmaterialWidth = 0.00m;
                    PrintingViewModel.RawmaterialGramWeight = 0.00m;
                    PrintingViewModel.WeightCost = 0.00m;
                    PrintingViewModel.WeightArea = 0.00m;
                    PrintingViewModel.PrintingLoss = 0.00m;
                    PrintingViewModel.ShiftLoss = 0.00m;
                    PrintingViewModel.Tax = 0.00m;
                }
                PrintingFormula = listItemEntity.Ext1Title;
            }
            else
            {
                PrintingViewModel.ProcessingFees = 0.00m;
                PrintingViewModel.RawmaterialWidth = 0.00m;
                PrintingViewModel.RawmaterialGramWeight = 0.00m;
                PrintingViewModel.WeightCost = 0.00m;
                PrintingViewModel.WeightArea = 0.00m;
                PrintingViewModel.PrintingLoss = 0.00m;
                PrintingViewModel.ShiftLoss = 0.00m;
                PrintingViewModel.Tax = 0.00m;
                PrintingFormula = string.Empty;
            }
            await PrintingFormulaCalc();
        }
        async Task PrintingFormulaCalc(decimal value = 0.00m)
        {
            try
            {
                string currentFormula = PrintingFormula;
                currentFormula = currentFormula.Replace("PE", PrintingViewModel.ProcessingFees.ToString()).Replace("RW", PrintingViewModel.RawmaterialWidth.ToString()).Replace("RG", PrintingViewModel.RawmaterialGramWeight.ToString());
                currentFormula = currentFormula.Replace("WC", PrintingViewModel.WeightCost.ToString()).Replace("WA", PrintingViewModel.WeightArea.ToString()).Replace("PL", PrintingViewModel.PrintingLoss.ToString());
                currentFormula = currentFormula.Replace("SL", PrintingViewModel.ShiftLoss.ToString()).Replace("T", PrintingViewModel.Tax.ToString()).Replace("PM", PrintingViewModel.ProfitMargin.ToString()); ;
                DataTable dt = new DataTable();
                PrintingViewModel.PrintingCost = decimal.Parse(dt.Compute(currentFormula, "").ToString());
            }
            catch (Exception ex)
            {
                await messageService.Error("计算公式错误，请确认", 2);
            }
            await Task.CompletedTask;
        }


        void ReturnHome()
        {
            navigationManager.NavigateTo("/");
        }
    }
}
